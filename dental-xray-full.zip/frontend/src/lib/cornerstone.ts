import * as cornerstone from 'cornerstone-core'
import * as cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader'
import dicomParser from 'dicom-parser'

let initialized = false

export function getCornerstone() {
  if (!initialized) {
    cornerstoneWADOImageLoader.external.cornerstone = cornerstone
    cornerstoneWADOImageLoader.external.dicomParser = dicomParser

    cornerstoneWADOImageLoader.configure({
      useWebWorkers: false,
    })

    initialized = true
  }

  return { cornerstone, cornerstoneWADOImageLoader }
}
