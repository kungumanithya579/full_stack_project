declare module 'cornerstone-core' {
  const cornerstone: any
  export = cornerstone
}

declare module 'cornerstone-wado-image-loader' {
  const cornerstoneWADOImageLoader: any
  export = cornerstoneWADOImageLoader
}

declare module 'dicom-parser' {
  const dicomParser: any
  export = dicomParser
}
