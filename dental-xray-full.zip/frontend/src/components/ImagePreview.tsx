import { useEffect, useState } from 'react'

interface ImagePreviewProps {
  file: File
  alt?: string
}

export function ImagePreview({ file, alt }: ImagePreviewProps) {
  const [objectUrl, setObjectUrl] = useState<string | null>(null)

  useEffect(() => {
    const url = URL.createObjectURL(file)
    setObjectUrl(url)
    return () => {
      if (url) {
        URL.revokeObjectURL(url)
      }
    }
  }, [file])

  if (!objectUrl) {
    return (
      <div className="image-preview image-preview--loading">
        <span>Loading image…</span>
      </div>
    )
  }

  return (
    <div className="image-preview">
      <img src={objectUrl} alt={alt ?? file.name} loading="lazy" />
    </div>
  )
}
