import { useEffect, useRef, useState } from 'react'
import { getCornerstone } from '../lib/cornerstone'

interface DicomPreviewProps {
  file: File
}

export function DicomPreview({ file }: DicomPreviewProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const { cornerstone, cornerstoneWADOImageLoader } = getCornerstone()
    const element = containerRef.current

    if (!element) {
      return
    }

    cornerstone.enable(element)
    let canceled = false
    let imageId: string | null = null

    async function loadDicom() {
      setError(null)
      try {
        imageId = cornerstoneWADOImageLoader.wadouri.fileManager.add(file)
        const image = await cornerstone.loadImage(imageId)
        if (canceled) {
          return
        }
        const viewport = cornerstone.getDefaultViewportForImage(element, image)
        cornerstone.displayImage(element, image)
        cornerstone.setViewport(element, viewport)
        setError(null)
      } catch (err) {
        console.error('Failed to render DICOM preview', err)
        const message =
          err instanceof Error ? err.message : 'Unable to render DICOM preview for this file.'
        setError(message)
      }
    }

    void loadDicom()

    return () => {
      canceled = true
      if (imageId) {
        cornerstoneWADOImageLoader.wadouri.fileManager.remove(imageId)
      }
      try {
        cornerstone.disable(element)
      } catch (err) {
        if (import.meta.env.DEV && err) {
          console.warn('Cornerstone disable warning:', err)
        }
      }
    }
  }, [file])

  return (
    <div className="dicom-preview">
      <div ref={containerRef} className="dicom-preview__viewport" role="presentation" />
      {error && <p className="dicom-preview__error">{error}</p>}
    </div>
  )
}
