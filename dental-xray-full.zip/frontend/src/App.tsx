import { useCallback, useMemo, useRef, useState } from 'react'
import type { ChangeEvent } from 'react'
import * as XLSX from 'xlsx'
import './App.css'
import { DicomPreview } from './components/DicomPreview'
import { ImagePreview } from './components/ImagePreview'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api/v1'
const MAX_ATTEMPTS = 2

type Detection = {
  detectionId?: string
  className?: string
  classId?: number
  confidence?: number
  x?: number
  y?: number
  width?: number
  height?: number
}

type DicomMetadata = {
  [key: string]: string | number | boolean | null | undefined | Array<string | number> | Array<number>
}

type ImageInfo = {
  [key: string]: string | number | boolean | null | undefined | Array<string | number> | Array<number>
}

type DetectionResponse = {
  predictions?: Detection[]
  metadata?: DicomMetadata
  imageInfo?: ImageInfo
  message?: string
  success?: boolean
  analysisSummary?: string
  isDicom?: boolean
}

type JobStatus = 'pending' | 'processing' | 'success' | 'error'

type FileJob = {
  id: string
  file: File
  status: JobStatus
  attempts: number
  result?: DetectionResponse
  error?: string
  isLikelyDicom: boolean
  startedAt?: number
  finishedAt?: number
}

const toNumber = (value: unknown) => {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : undefined
  }
  return undefined
}

const toStringValue = (value: unknown) => {
  if (typeof value === 'string') {
    const trimmed = value.trim()
    return trimmed.length > 0 ? trimmed : undefined
  }
  if (typeof value === 'number' || typeof value === 'bigint') return String(value)
  return undefined
}

const normalizeDetection = (raw: Detection | Record<string, unknown>): Detection => {
  const candidate = raw as Record<string, unknown>

  const classCandidate =
    (candidate.className as unknown) ?? candidate['class'] ?? candidate.label ?? candidate['condition']

  return {
    detectionId: toStringValue(candidate.detectionId ?? candidate['detection_id']),
    className: toStringValue(classCandidate),
    classId: toNumber(candidate.classId ?? candidate['class_id']),
    confidence: toNumber(candidate.confidence),
    x: toNumber(candidate.x),
    y: toNumber(candidate.y),
    width: toNumber(candidate.width),
    height: toNumber(candidate.height),
  }
}

const formatLabel = (key: string) =>
  key
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase())

const isMeaningfulValue = (value: unknown) => {
  if (value === null || value === undefined) return false
  if (Array.isArray(value)) return value.length > 0
  if (typeof value === 'string') return value.trim().length > 0
  return true
}

const isLikelyDicomFile = (file: File) => {
  const name = file.name.toLowerCase()
  const type = file.type.toLowerCase()
  return (
    name.endsWith('.dcm') ||
    name.endsWith('.dicom') ||
    type === 'application/dicom' ||
    type === 'application/dicom+json' ||
    type === 'application/dicom+xml'
  )
}

const createJob = (file: File): FileJob => ({
  id: typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${file.name}-${Date.now()}`,
  file,
  status: 'pending',
  attempts: 0,
  isLikelyDicom: isLikelyDicomFile(file),
})

const sanitizeSheetName = (name: string) => {
  const sanitized = name.replace(/[\\/:*?\[\]]/g, ' ').slice(0, 31)
  return sanitized.length ? sanitized : 'Sheet'
}

const useJobsState = () => {
  const [jobs, setJobs] = useState<FileJob[]>([])
  const jobsRef = useRef<FileJob[]>([])

  const updateJobs = useCallback((updater: (current: FileJob[]) => FileJob[]) => {
    setJobs((current) => {
      const next = updater(current)
      jobsRef.current = next
      return next
    })
  }, [])

  return { jobs, jobsRef, updateJobs }
}

function App() {
  const { jobs, jobsRef, updateJobs } = useJobsState()
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [globalError, setGlobalError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? [])

    if (files.length === 0) {
      updateJobs(() => [])
      setGlobalError(null)
      setNotice(null)
      return
    }

    const nextJobs = files.map((file) => createJob(file))
    updateJobs(() => nextJobs)
    setGlobalError(null)
    setNotice(null)
    event.target.value = ''
  }

  const analyzeQueue = useCallback(async () => {
    const queue = [...jobsRef.current]

    if (queue.length === 0) {
      setGlobalError('Please upload at least one file to analyze.')
      return
    }

    setIsAnalyzing(true)
    setGlobalError(null)
    setNotice('Starting analysis…')

    for (let index = 0; index < queue.length; index += 1) {
      const queuedJob = queue[index]
      let attempt = 0
      let success = false
      let lastError = ''

      while (attempt < MAX_ATTEMPTS && !success) {
        attempt += 1

        updateJobs((current) =>
          current.map((job) =>
            job.id === queuedJob.id
              ? {
                  ...job,
                  status: 'processing',
                  attempts: attempt,
                  startedAt: job.startedAt ?? Date.now(),
                  error: undefined,
                }
              : job
          )
        )

        try {
          setNotice(`Analyzing ${queuedJob.file.name} (${index + 1}/${queue.length}) — attempt ${attempt}`)

          const formData = new FormData()
          formData.append('file', queuedJob.file)

          const response = await fetch(`${API_BASE_URL}/detect`, {
            method: 'POST',
            body: formData,
          })

          const responseText = await response.text()
          let data: DetectionResponse | null = null

          if (responseText) {
            try {
              data = JSON.parse(responseText) as DetectionResponse
            } catch (parseError) {
              throw new Error('Received a non-JSON response from the server.')
            }
          }

          if (!response.ok) {
            const serverMessage =
              data?.message || (data as { error?: string })?.error || response.statusText || 'Request failed'
            throw new Error(serverMessage)
          }

          const normalizedPredictions = Array.isArray(data?.predictions)
            ? data?.predictions.map((prediction) => normalizeDetection(prediction))
            : []

          const result: DetectionResponse = {
            ...data,
            predictions: normalizedPredictions,
          }

          updateJobs((current) =>
            current.map((job) =>
              job.id === queuedJob.id
                ? {
                    ...job,
                    status: 'success',
                    result,
                    finishedAt: Date.now(),
                    isLikelyDicom: result.isDicom ?? job.isLikelyDicom,
                    error: undefined,
                  }
                : job
            )
          )

          success = true
        } catch (error) {
          const message =
            error instanceof Error ? error.message : 'Unexpected error while analyzing this file.'
          lastError = message

          if (attempt < MAX_ATTEMPTS) {
            await new Promise((resolve) => setTimeout(resolve, 750))
          }
        }
      }

      if (!success) {
        updateJobs((current) =>
          current.map((job) =>
            job.id === queuedJob.id
              ? {
                  ...job,
                  status: 'error',
                  error: lastError || 'Failed to analyze this file after retrying.',
                  finishedAt: Date.now(),
                }
              : job
          )
        )
      }
    }

    setNotice('Finished processing all files.')
    setIsAnalyzing(false)
  }, [jobsRef, updateJobs])

  const exportToExcel = useCallback(() => {
    const completedJobs = jobsRef.current.filter((job) => job.status === 'success' && job.result)

    if (completedJobs.length === 0) {
      setGlobalError('No completed analyses to export yet.')
      return
    }

    const workbook = XLSX.utils.book_new()

    completedJobs.forEach((job) => {
      const rows: Array<Array<string | number | undefined>> = []
      const { result } = job

      rows.push(['File Name', job.file.name])
      rows.push(['Status', job.status])
  rows.push(['Analyzed At', job.finishedAt ? new Date(job.finishedAt).toISOString() : '—'])
      rows.push(['Is DICOM', result?.isDicom ? 'Yes' : 'No'])
      rows.push([''])

      rows.push(['Analysis Summary'])
      rows.push([result?.analysisSummary ?? '—'])
      rows.push([''])

      rows.push(['Detections'])
      rows.push(['ID', 'Class', 'Confidence', 'X', 'Y', 'Width', 'Height'])
      if (result?.predictions?.length) {
        result.predictions.forEach((detection) => {
          rows.push([
            detection.detectionId ?? undefined,
            detection.className ?? (detection.classId !== undefined ? `Class ${detection.classId}` : undefined),
            detection.confidence !== undefined ? `${(detection.confidence * 100).toFixed(2)}%` : undefined,
            detection.x,
            detection.y,
            detection.width,
            detection.height,
          ])
        })
      } else {
        rows.push(['No detections'])
      }

      rows.push([''])

      const metadataEntries = Object.entries((result?.metadata ?? {}) as Record<string, unknown>).filter(([, value]) =>
        isMeaningfulValue(value)
      )
      const imageInfoEntries = Object.entries((result?.imageInfo ?? {}) as Record<string, unknown>).filter(([, value]) =>
        isMeaningfulValue(value)
      )

      if (metadataEntries.length > 0) {
        rows.push(['Metadata'])
        metadataEntries.forEach(([key, value]) => {
          rows.push([formatLabel(key), Array.isArray(value) ? value.join(', ') : String(value)])
        })
        rows.push([''])
      }

      if (imageInfoEntries.length > 0) {
        rows.push(['Image Info'])
        imageInfoEntries.forEach(([key, value]) => {
          rows.push([formatLabel(key), Array.isArray(value) ? value.join(', ') : String(value)])
        })
      }

      const worksheet = XLSX.utils.aoa_to_sheet(rows)
      XLSX.utils.book_append_sheet(workbook, worksheet, sanitizeSheetName(job.file.name))
    })

    XLSX.writeFile(workbook, `dental-detections-${Date.now()}.xlsx`)
    setNotice('Export completed successfully.')
  }, [jobsRef])

  const completedCount = useMemo(
    () => jobs.filter((job) => job.status === 'success').length,
    [jobs]
  )

  const hasPending = useMemo(
    () => jobs.some((job) => job.status === 'pending' || job.status === 'processing'),
    [jobs]
  )

  return (
    <div className="app">
      <header className="app__header">
        <h1>Dental Conditions Detection</h1>
        <p className="app__subtitle">
          Upload DICOM studies and standard dental images together, analyze them sequentially, and review
          richly structured AI results per image.
        </p>
      </header>

      <section className="panel">
        <h2 className="panel__title">Upload Studies or Images</h2>
        <label className="upload">
          <input
            type="file"
            multiple
            accept=".dcm,.dicom,application/dicom,image/*"
            onChange={handleFileChange}
          />
          <span>Click or drag DICOM / standard images to upload</span>
          <small>Supported: .dcm, .dicom, JPG, JPEG, PNG, WEBP</small>
        </label>

        <div className="panel__actions">
          <button
            className="analyze-button"
            onClick={analyzeQueue}
            disabled={isAnalyzing || jobs.length === 0}
          >
            {isAnalyzing ? 'Analyzing queue…' : 'Analyze all'}
          </button>
          <button
            className="export-button"
            onClick={exportToExcel}
            disabled={jobs.length === 0 || hasPending || completedCount === 0}
          >
            Export to Excel
          </button>
        </div>

        {jobs.length > 0 && (
          <p className="notice">
            {completedCount} of {jobs.length} files completed.
          </p>
        )}

        {globalError && <p className="error">{globalError}</p>}
        {notice && <p className="success">{notice}</p>}
      </section>

      {jobs.length > 0 && (
        <section className="results">
          <h2 className="results__title">Analysis Gallery</h2>
          <div className="results-grid">
            {jobs.map((job) => (
              <FileAnalysisCard key={job.id} job={job} isAnalyzing={isAnalyzing} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

type FileAnalysisCardProps = {
  job: FileJob
  isAnalyzing: boolean
}

function FileAnalysisCard({ job, isAnalyzing }: FileAnalysisCardProps) {
  const { file, status, attempts, result, error, isLikelyDicom } = job

  const displayIsDicom = result?.isDicom ?? isLikelyDicom
  const metadataEntries = Object.entries((result?.metadata ?? {}) as Record<string, unknown>).filter(([, value]) =>
    isMeaningfulValue(value)
  )
  const imageInfoEntries = Object.entries((result?.imageInfo ?? {}) as Record<string, unknown>).filter(([, value]) =>
    isMeaningfulValue(value)
  )

  const detections = result?.predictions ?? []

  return (
    <article className={`file-card file-card--${status}`}>
      <header className="file-card__header">
        <h3 title={file.name}>{file.name}</h3>
        <StatusBadge status={status} attempts={attempts} isAnalyzing={isAnalyzing} />
      </header>

      <div className="file-card__preview">
        {displayIsDicom ? <DicomPreview file={file} /> : <ImagePreview file={file} alt={file.name} />}
      </div>

      {status === 'processing' && (
        <div className="file-card__loader">
          <span className="spinner" aria-hidden />
          <p>Analyzing (attempt {attempts} of {MAX_ATTEMPTS})…</p>
        </div>
      )}

      {status === 'error' && error && <p className="file-card__error">{error}</p>}

      {status === 'success' && result && (
        <div className="file-card__details">
          {result.analysisSummary && (
            <section className="file-card__section">
              <h4>AI Summary</h4>
              <p>{result.analysisSummary}</p>
            </section>
          )}

          {detections.length > 0 && (
            <section className="file-card__section">
              <h4>Detections</h4>
              <div className="mini-table" role="group" aria-label="Detections table">
                <div className="mini-table__row mini-table__row--header">
                  <span>ID</span>
                  <span>Class</span>
                  <span>Confidence</span>
                </div>
                {detections.map((detection, index) => (
                  <div key={detection.detectionId ?? index} className="mini-table__row">
                    <span>{detection.detectionId ?? '—'}</span>
                    <span>{detection.className ?? (detection.classId !== undefined ? `Class ${detection.classId}` : '—')}</span>
                    <span>
                      {detection.confidence !== undefined
                        ? `${(detection.confidence * 100).toFixed(1)}%`
                        : '—'}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          )}

          {(metadataEntries.length > 0 || imageInfoEntries.length > 0) && (
            <section className="file-card__section">
              <h4>Study Insights</h4>
              <dl className="info-grid info-grid--compact">
                {metadataEntries.slice(0, 6).map(([key, value]) => (
                  <div key={`metadata-${key}`} className="info-grid__item">
                    <dt>{formatLabel(key)}</dt>
                    <dd>{Array.isArray(value) ? value.join(', ') : String(value)}</dd>
                  </div>
                ))}
                {imageInfoEntries.slice(0, 6).map(([key, value]) => (
                  <div key={`image-${key}`} className="info-grid__item">
                    <dt>{formatLabel(key)}</dt>
                    <dd>{Array.isArray(value) ? value.join(', ') : String(value)}</dd>
                  </div>
                ))}
              </dl>
              {(metadataEntries.length > 6 || imageInfoEntries.length > 6) && (
                <p className="file-card__hint">Additional details are included in the Excel export.</p>
              )}
            </section>
          )}

          {detections.length === 0 && metadataEntries.length === 0 && imageInfoEntries.length === 0 && (
            <p className="file-card__hint">No structured insights were returned for this image.</p>
          )}
        </div>
      )}
    </article>
  )
}

type StatusBadgeProps = {
  status: JobStatus
  attempts: number
  isAnalyzing: boolean
}

function StatusBadge({ status, attempts, isAnalyzing }: StatusBadgeProps) {
  switch (status) {
    case 'success':
      return <span className="status-badge status-badge--success">Completed</span>
    case 'processing':
      return (
        <span className="status-badge status-badge--processing">
          {isAnalyzing ? `Processing (attempt ${attempts}/${MAX_ATTEMPTS})` : 'Processing'}
        </span>
      )
    case 'error':
      return <span className="status-badge status-badge--error">Needs Attention</span>
    default:
      return <span className="status-badge status-badge--pending">Pending</span>
  }
}

export default App
