package com.dental.model;

import java.util.ArrayList;
import java.util.List;

public class StructuredDetectionResult {

    private String description;
    private List<Detection> predictions = new ArrayList<>();

    public StructuredDetectionResult() {
    }

    public StructuredDetectionResult(String description, List<Detection> predictions) {
        this.description = description;
        this.predictions = predictions;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Detection> getPredictions() {
        return predictions;
    }

    public void setPredictions(List<Detection> predictions) {
        this.predictions = predictions;
    }
}
