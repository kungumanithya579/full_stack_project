package com.dental.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ImageInfo {
    
    @JsonProperty("original_shape")
    private List<Integer> originalShape;
    
    @JsonProperty("converted_format")
    private String convertedFormat;
    
    @JsonProperty("converted_size")
    private List<Integer> convertedSize;
    
    @JsonProperty("original_dtype")
    private String originalDtype;
    
    @JsonProperty("pixel_array_min")
    private double pixelArrayMin;
    
    @JsonProperty("pixel_array_max")
    private double pixelArrayMax;
    
    @JsonProperty("photometric_interpretation")
    private String photometricInterpretation;
    
    @JsonProperty("transfer_syntax")
    private String transferSyntax;

    public ImageInfo() {}

    public ImageInfo(List<Integer> originalShape, String convertedFormat, List<Integer> convertedSize,
                     String originalDtype, double pixelArrayMin, double pixelArrayMax,
                     String photometricInterpretation, String transferSyntax) {
        this.originalShape = originalShape;
        this.convertedFormat = convertedFormat;
        this.convertedSize = convertedSize;
        this.originalDtype = originalDtype;
        this.pixelArrayMin = pixelArrayMin;
        this.pixelArrayMax = pixelArrayMax;
        this.photometricInterpretation = photometricInterpretation;
        this.transferSyntax = transferSyntax;
    }

    public List<Integer> getOriginalShape() {
        return originalShape;
    }

    public void setOriginalShape(List<Integer> originalShape) {
        this.originalShape = originalShape;
    }

    public String getConvertedFormat() {
        return convertedFormat;
    }

    public void setConvertedFormat(String convertedFormat) {
        this.convertedFormat = convertedFormat;
    }

    public List<Integer> getConvertedSize() {
        return convertedSize;
    }

    public void setConvertedSize(List<Integer> convertedSize) {
        this.convertedSize = convertedSize;
    }

    public String getOriginalDtype() {
        return originalDtype;
    }

    public void setOriginalDtype(String originalDtype) {
        this.originalDtype = originalDtype;
    }

    public double getPixelArrayMin() {
        return pixelArrayMin;
    }

    public void setPixelArrayMin(double pixelArrayMin) {
        this.pixelArrayMin = pixelArrayMin;
    }

    public double getPixelArrayMax() {
        return pixelArrayMax;
    }

    public void setPixelArrayMax(double pixelArrayMax) {
        this.pixelArrayMax = pixelArrayMax;
    }

    public String getPhotometricInterpretation() {
        return photometricInterpretation;
    }

    public void setPhotometricInterpretation(String photometricInterpretation) {
        this.photometricInterpretation = photometricInterpretation;
    }

    public String getTransferSyntax() {
        return transferSyntax;
    }

    public void setTransferSyntax(String transferSyntax) {
        this.transferSyntax = transferSyntax;
    }
}