package com.dental.model;

import java.util.ArrayList;
import java.util.List;

public class VisionAnalysis {

    private String narrative;
    private String rawResponse;
    private List<Detection> directDetections = new ArrayList<>();

    public VisionAnalysis() {
    }

    public VisionAnalysis(String narrative, String rawResponse, List<Detection> directDetections) {
        this.narrative = narrative;
        this.rawResponse = rawResponse;
        if (directDetections != null) {
            this.directDetections = directDetections;
        }
    }

    public String getNarrative() {
        return narrative;
    }

    public void setNarrative(String narrative) {
        this.narrative = narrative;
    }

    public String getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(String rawResponse) {
        this.rawResponse = rawResponse;
    }

    public List<Detection> getDirectDetections() {
        return directDetections;
    }

    public void setDirectDetections(List<Detection> directDetections) {
        if (directDetections == null) {
            this.directDetections = new ArrayList<>();
        } else {
            this.directDetections = directDetections;
        }
    }
}
