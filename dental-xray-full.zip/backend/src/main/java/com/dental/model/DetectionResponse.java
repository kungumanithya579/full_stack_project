package com.dental.model;

import java.util.List;

public class DetectionResponse {
    
    private List<Detection> predictions;
    private DicomMetadata metadata;
    private ImageInfo imageInfo;
    private String message;
    private boolean success;
    private String analysisSummary;
    private boolean isDicom;

    public DetectionResponse() {}

    public DetectionResponse(List<Detection> predictions, DicomMetadata metadata, ImageInfo imageInfo) {
        this.predictions = predictions;
        this.metadata = metadata;
        this.imageInfo = imageInfo;
        this.success = true;
        this.message = "Detection completed successfully";
        this.isDicom = metadata != null;
    }

    public DetectionResponse(List<Detection> predictions, DicomMetadata metadata, ImageInfo imageInfo, boolean isDicom) {
        this.predictions = predictions;
        this.metadata = metadata;
        this.imageInfo = imageInfo;
        this.success = true;
        this.message = "Detection completed successfully";
        this.isDicom = isDicom;
    }

    public DetectionResponse(String message, boolean success) {
        this.message = message;
        this.success = success;
    }

    public List<Detection> getPredictions() {
        return predictions;
    }

    public void setPredictions(List<Detection> predictions) {
        this.predictions = predictions;
    }

    public DicomMetadata getMetadata() {
        return metadata;
    }

    public void setMetadata(DicomMetadata metadata) {
        this.metadata = metadata;
    }

    public ImageInfo getImageInfo() {
        return imageInfo;
    }

    public void setImageInfo(ImageInfo imageInfo) {
        this.imageInfo = imageInfo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getAnalysisSummary() {
        return analysisSummary;
    }

    public void setAnalysisSummary(String analysisSummary) {
        this.analysisSummary = analysisSummary;
    }

    public boolean isDicom() {
        return isDicom;
    }

    public void setDicom(boolean isDicom) {
        this.isDicom = isDicom;
    }
}