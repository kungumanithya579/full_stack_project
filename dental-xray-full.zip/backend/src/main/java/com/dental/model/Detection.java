package com.dental.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Detection {
    
    private double x;
    private double y;
    private int width;
    private int height;
    private double confidence;
    
    @JsonProperty("class")
    private String className;
    
    @JsonProperty("class_id")
    private int classId;
    
    @JsonProperty("detection_id")
    private String detectionId;

    public Detection() {}

    public Detection(double x, double y, int width, int height, double confidence, 
                    String className, int classId, String detectionId) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.confidence = confidence;
        this.className = className;
        this.classId = classId;
        this.detectionId = detectionId;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public String getDetectionId() {
        return detectionId;
    }

    public void setDetectionId(String detectionId) {
        this.detectionId = detectionId;
    }

    @Override
    public String toString() {
        return "Detection{" +
                "x=" + x +
                ", y=" + y +
                ", width=" + width +
                ", height=" + height +
                ", confidence=" + confidence +
                ", className='" + className + '\'' +
                ", classId=" + classId +
                ", detectionId='" + detectionId + '\'' +
                '}';
    }
}