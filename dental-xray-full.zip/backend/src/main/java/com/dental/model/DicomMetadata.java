package com.dental.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class DicomMetadata {
    
    @JsonProperty("patient_id")
    private String patientId;
    
    @JsonProperty("patient_name")
    private String patientName;
    
    @JsonProperty("patient_birth_date")
    private String patientBirthDate;
    
    @JsonProperty("patient_sex")
    private String patientSex;
    
    @JsonProperty("study_date")
    private String studyDate;
    
    @JsonProperty("study_time")
    private String studyTime;
    
    @JsonProperty("study_description")
    private String studyDescription;
    
    @JsonProperty("series_description")
    private String seriesDescription;
    
    private String modality;
    private String manufacturer;
    
    @JsonProperty("manufacturer_model_name")
    private String manufacturerModelName;
    
    private Integer rows;
    private Integer columns;
    
    @JsonProperty("pixel_spacing")
    private List<Double> pixelSpacing;
    
    @JsonProperty("bits_allocated")
    private Integer bitsAllocated;
    
    @JsonProperty("bits_stored")
    private Integer bitsStored;
    
    @JsonProperty("photometric_interpretation")
    private String photometricInterpretation;
    
    @JsonProperty("acquisition_date")
    private String acquisitionDate;
    
    @JsonProperty("acquisition_time")
    private String acquisitionTime;
    
    @JsonProperty("institution_name")
    private String institutionName;
    
    @JsonProperty("referring_physician_name")
    private String referringPhysicianName;
    
    @JsonProperty("study_instance_uid")
    private String studyInstanceUID;
    
    @JsonProperty("series_instance_uid")
    private String seriesInstanceUID;
    
    @JsonProperty("sop_instance_uid")
    private String sopInstanceUID;
    
    @JsonProperty("high_bit")
    private Integer highBit;
    
    @JsonProperty("samples_per_pixel")
    private Integer samplesPerPixel;
    
    @JsonProperty("window_center")
    private Double windowCenter;
    
    @JsonProperty("window_width")
    private Double windowWidth;
    
    @JsonProperty("transfer_syntax")
    private String transferSyntax;

    public DicomMetadata() {}

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientBirthDate() {
        return patientBirthDate;
    }

    public void setPatientBirthDate(String patientBirthDate) {
        this.patientBirthDate = patientBirthDate;
    }

    public String getPatientSex() {
        return patientSex;
    }

    public void setPatientSex(String patientSex) {
        this.patientSex = patientSex;
    }

    public String getStudyDate() {
        return studyDate;
    }

    public void setStudyDate(String studyDate) {
        this.studyDate = studyDate;
    }

    public String getStudyTime() {
        return studyTime;
    }

    public void setStudyTime(String studyTime) {
        this.studyTime = studyTime;
    }

    public String getStudyDescription() {
        return studyDescription;
    }

    public void setStudyDescription(String studyDescription) {
        this.studyDescription = studyDescription;
    }

    public String getSeriesDescription() {
        return seriesDescription;
    }

    public void setSeriesDescription(String seriesDescription) {
        this.seriesDescription = seriesDescription;
    }

    public String getModality() {
        return modality;
    }

    public void setModality(String modality) {
        this.modality = modality;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturerModelName() {
        return manufacturerModelName;
    }

    public void setManufacturerModelName(String manufacturerModelName) {
        this.manufacturerModelName = manufacturerModelName;
    }

    public Integer getRows() {
        return rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    public Integer getColumns() {
        return columns;
    }

    public void setColumns(Integer columns) {
        this.columns = columns;
    }

    public List<Double> getPixelSpacing() {
        return pixelSpacing;
    }

    public void setPixelSpacing(List<Double> pixelSpacing) {
        this.pixelSpacing = pixelSpacing;
    }

    public Integer getBitsAllocated() {
        return bitsAllocated;
    }

    public void setBitsAllocated(Integer bitsAllocated) {
        this.bitsAllocated = bitsAllocated;
    }

    public Integer getBitsStored() {
        return bitsStored;
    }

    public void setBitsStored(Integer bitsStored) {
        this.bitsStored = bitsStored;
    }

    public String getPhotometricInterpretation() {
        return photometricInterpretation;
    }

    public void setPhotometricInterpretation(String photometricInterpretation) {
        this.photometricInterpretation = photometricInterpretation;
    }

    public String getAcquisitionDate() {
        return acquisitionDate;
    }

    public void setAcquisitionDate(String acquisitionDate) {
        this.acquisitionDate = acquisitionDate;
    }

    public String getAcquisitionTime() {
        return acquisitionTime;
    }

    public void setAcquisitionTime(String acquisitionTime) {
        this.acquisitionTime = acquisitionTime;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getReferringPhysicianName() {
        return referringPhysicianName;
    }

    public void setReferringPhysicianName(String referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
    }
    
    public String getStudyInstanceUID() {
        return studyInstanceUID;
    }
    
    public void setStudyInstanceUID(String studyInstanceUID) {
        this.studyInstanceUID = studyInstanceUID;
    }
    
    public String getSeriesInstanceUID() {
        return seriesInstanceUID;
    }
    
    public void setSeriesInstanceUID(String seriesInstanceUID) {
        this.seriesInstanceUID = seriesInstanceUID;
    }
    
    public String getSOPInstanceUID() {
        return sopInstanceUID;
    }
    
    public void setSOPInstanceUID(String sopInstanceUID) {
        this.sopInstanceUID = sopInstanceUID;
    }
    
    public Integer getHighBit() {
        return highBit;
    }
    
    public void setHighBit(Integer highBit) {
        this.highBit = highBit;
    }
    
    public Integer getSamplesPerPixel() {
        return samplesPerPixel;
    }
    
    public void setSamplesPerPixel(Integer samplesPerPixel) {
        this.samplesPerPixel = samplesPerPixel;
    }
    
    public Double getWindowCenter() {
        return windowCenter;
    }
    
    public void setWindowCenter(Double windowCenter) {
        this.windowCenter = windowCenter;
    }
    
    public Double getWindowWidth() {
        return windowWidth;
    }
    
    public void setWindowWidth(Double windowWidth) {
        this.windowWidth = windowWidth;
    }
    
    public String getTransferSyntax() {
        return transferSyntax;
    }
    
    public void setTransferSyntax(String transferSyntax) {
        this.transferSyntax = transferSyntax;
    }
}