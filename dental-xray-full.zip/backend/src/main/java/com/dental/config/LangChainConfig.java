package com.dental.config;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.ollama.OllamaChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class LangChainConfig {

    private final OllamaConfig ollamaConfig;

    public LangChainConfig(OllamaConfig ollamaConfig) {
        this.ollamaConfig = ollamaConfig;
    }

    @Bean
    public ChatLanguageModel ollamaChatLanguageModel() {
        return OllamaChatModel.builder()
                .baseUrl(ollamaConfig.getUrl())
                .modelName(ollamaConfig.getModel())
                .temperature(ollamaConfig.getTemperature())
                .timeout(Duration.ofSeconds(ollamaConfig.getTimeoutSeconds()))
                .build();
    }
}
