package com.dental.controller;

import com.dental.model.*;
import com.dental.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

@RestController
@RequestMapping("/detect")
public class DetectionController {

    private static final Logger logger = LoggerFactory.getLogger(DetectionController.class);

    private final FileValidationService fileValidationService;
    private final DicomProcessingService dicomProcessingService;
    private final ImageProcessingService imageProcessingService;
    private final GeminiVisionService geminiVisionService;
    private final StructuredDetectionService structuredDetectionService;

    public DetectionController(
            FileValidationService fileValidationService,
            DicomProcessingService dicomProcessingService,
            ImageProcessingService imageProcessingService,
            GeminiVisionService geminiVisionService,
            StructuredDetectionService structuredDetectionService) {
        this.fileValidationService = fileValidationService;
        this.dicomProcessingService = dicomProcessingService;
        this.imageProcessingService = imageProcessingService;
        this.geminiVisionService = geminiVisionService;
        this.structuredDetectionService = structuredDetectionService;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> detectDentalConditions(@RequestParam("file") MultipartFile file) {
        
        File tempFile = null;
        File tempImageFile = null;
        
        try {
            logger.info("Received file for detection: {} (size: {} bytes)", 
                file.getOriginalFilename(), file.getSize());

            fileValidationService.validateFile(file);

            tempFile = saveMultipartFileTemporarily(file);
            
            boolean isDicomFile = dicomProcessingService.isDicomFile(tempFile);
            boolean isRegularImageFile = fileValidationService.isRegularImageFile(file.getOriginalFilename());
            
            if (!isDicomFile && !isRegularImageFile) {
                return ResponseEntity.badRequest()
                    .body(new ErrorResponse("INVALID_FILE", 
                        "File must be either a valid DICOM file or a regular image file (PNG, JPG, JPEG, WEBP)", 400));
            }

            DicomMetadata metadata = null;
            ImageInfo imageInfo = null;
            
            if (isDicomFile) {
                // Process DICOM file
                logger.info("Processing DICOM file: {}", file.getOriginalFilename());
                metadata = dicomProcessingService.extractDicomMetadata(tempFile);
                tempImageFile = imageProcessingService.convertDicomToJpeg(tempFile);
                imageInfo = imageProcessingService.createImageInfo(tempFile, tempImageFile);
            } else {
                // Process regular image file
                logger.info("Processing regular image file: {}", file.getOriginalFilename());
                tempImageFile = tempFile; // Use the original file directly
                imageInfo = imageProcessingService.createImageInfoForRegularImage(tempImageFile);
            }

            VisionAnalysis analysis = geminiVisionService.analyzeImage(tempImageFile);
            System.out.println(analysis.getNarrative());

            StructuredDetectionResult structuredResult = structuredDetectionService.structureDetections(analysis);
            List<Detection> detections = structuredResult.getPredictions();

            DetectionResponse response = new DetectionResponse(detections, metadata, imageInfo, isDicomFile);
            response.setAnalysisSummary(structuredResult.getDescription());

            logger.info("Successfully processed file: {} with {} detections (isDicom: {})", 
                file.getOriginalFilename(), detections.size(), isDicomFile);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            logger.warn("File validation failed: {}", e.getMessage());
            return ResponseEntity.badRequest()
                .body(new ErrorResponse("VALIDATION_ERROR", e.getMessage(), 400));
                
        } catch (IOException e) {
            logger.error("IO error processing file: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse("IO_ERROR", 
                    "Error processing file: " + e.getMessage(), 500));
                    
        } catch (Exception e) {
            logger.error("Unexpected error processing file: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse("PROCESSING_ERROR", 
                    "Unexpected error occurred during processing", 500));
                    
        } finally {
            cleanupTempFile(tempFile);
            // Only cleanup tempImageFile if it's different from tempFile
            if (tempImageFile != null && !tempImageFile.equals(tempFile)) {
                cleanupTempFile(tempImageFile);
            }
        }
    }

    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Dental Detection Service is healthy");
    }

    private File saveMultipartFileTemporarily(MultipartFile multipartFile) throws IOException {
        String originalFilename = multipartFile.getOriginalFilename();
        String suffix = ".tmp";
        
        if (originalFilename != null && originalFilename.contains(".")) {
            suffix = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
            
        File tempFile = File.createTempFile("upload_", suffix);
        
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(multipartFile.getBytes());
        }
        
        logger.debug("Saved temporary file: {}", tempFile.getAbsolutePath());
        return tempFile;
    }

    private void cleanupTempFile(File file) {
        if (file != null && file.exists()) {
            try {
                Files.delete(file.toPath());
                logger.debug("Cleaned up temporary file: {}", file.getAbsolutePath());
            } catch (IOException e) {
                logger.warn("Failed to delete temporary file: {}", file.getAbsolutePath(), e);
            }
        }
    }
}