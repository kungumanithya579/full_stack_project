package com.dental.service;

import com.dental.config.UploadConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileValidationService {

    private static final Logger logger = LoggerFactory.getLogger(FileValidationService.class);
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

    private final UploadConfig uploadConfig;

    public FileValidationService(UploadConfig uploadConfig) {
        this.uploadConfig = uploadConfig;
    }

    public void validateFile(MultipartFile file) throws IllegalArgumentException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be null or empty");
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException(
                String.format("File size (%d bytes) exceeds maximum allowed size (%d bytes)", 
                    file.getSize(), MAX_FILE_SIZE)
            );
        }

        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            throw new IllegalArgumentException("File must have a valid filename");
        }

        boolean validExtension = uploadConfig.getAllowedExtensions().stream()
            .anyMatch(ext -> originalFilename.toLowerCase().endsWith(ext.toLowerCase()));

        if (!validExtension) {
            throw new IllegalArgumentException(
                String.format("File must have one of the following extensions: %s", 
                    String.join(", ", uploadConfig.getAllowedExtensions()))
            );
        }

        String contentType = file.getContentType();
        logger.debug("File content type: {}", contentType);

        logger.info("File validation passed for: {} (size: {} bytes)", 
            originalFilename, file.getSize());
    }

    public boolean isRegularImageFile(String filename) {
        if (filename == null) {
            return false;
        }
        String lowerCaseFilename = filename.toLowerCase();
        return lowerCaseFilename.endsWith(".png") || 
               lowerCaseFilename.endsWith(".jpg") || 
               lowerCaseFilename.endsWith(".jpeg") || 
               lowerCaseFilename.endsWith(".webp");
    }
}