package com.dental.service;

import com.dental.model.Detection;
import com.dental.model.VisionAnalysis;
import com.dental.model.StructuredDetectionResult;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class StructuredDetectionService {

    private static final Logger logger = LoggerFactory.getLogger(StructuredDetectionService.class);
    private static final int LOG_PREVIEW_LIMIT = 800;

    private final DentalAnalysisExtractor analysisExtractor;

    public StructuredDetectionService(ChatLanguageModel chatLanguageModel) {
        this.analysisExtractor = AiServices.create(DentalAnalysisExtractor.class, chatLanguageModel);
    }

    interface DentalAnalysisExtractor {
        
        @SystemMessage("You are a dental radiology assistant. Extract structured information from dental image analysis reports.")
        @UserMessage("""
                Analyze the provided description from a vision model and extract structured information.
                The analysis contains a 'Summary' paragraph followed by 'Findings' bullets.
                Extract predictions with their spatial coordinates (x, y, width, height), confidence scores (0-1), 
                and classification (class name and class_id).
                Use -1 for numeric fields if not provided in the source.
                
                Analysis:
                {{narrative}}
                """)
        StructuredPayload extractStructuredData(String narrative);
    }

    public StructuredDetectionResult structureDetections(VisionAnalysis analysis) {
        String narrative = sanitizeNarrative(analysis);

        StructuredDetectionResult result = new StructuredDetectionResult();
        result.setDescription(narrative);
        result.setPredictions(new ArrayList<>());

        logger.info("Narrative received from Gemini (preview): {}", preview(narrative));

        if (isBlank(narrative)) {
            logger.warn("Narrative from Gemini is empty. Falling back to direct detections.");
            result.setPredictions(analysis.getDirectDetections());
            logger.info("Structured detection result ready via fallback: {} predictions", result.getPredictions().size());
            return ensureDetectionIds(result);
        }

        try {
            logger.info("Forwarding narrative to Ollama for structuring ({} chars)", narrative.length());
            
            StructuredPayload payload = analysisExtractor.extractStructuredData(narrative);
            
            logger.info("Ollama structured response received: {} predictions", 
                    payload.getPredictions() != null ? payload.getPredictions().size() : 0);

            if (isNotBlank(payload.getDescription())) {
                result.setDescription(payload.getDescription());
            }

            List<Detection> structuredDetections = mapToDetections(payload.getPredictions());

            if (structuredDetections.isEmpty()) {
                logger.warn("LangChain4j returned no predictions, falling back to direct detections");
                structuredDetections = analysis.getDirectDetections();
            }

            result.setPredictions(structuredDetections);
            logger.info("Structured detection result ready: {} predictions, summary length={} chars",
                    result.getPredictions().size(),
                    result.getDescription() != null ? result.getDescription().length() : 0);
            return ensureDetectionIds(result);

        } catch (Exception ex) {
            logger.warn("Failed to extract structured output via LangChain4j: {}", ex.getMessage());
            result.setPredictions(analysis.getDirectDetections());
            logger.info("Structured detection result ready via exception fallback: {} predictions",
                    result.getPredictions().size());
            return ensureDetectionIds(result);
        }
    }

    private StructuredDetectionResult ensureDetectionIds(StructuredDetectionResult result) {
        if (result.getPredictions() == null) {
            result.setPredictions(new ArrayList<>());
        }
        result.getPredictions().forEach(detection -> {
            if (detection.getDetectionId() == null || detection.getDetectionId().isBlank()) {
                detection.setDetectionId(UUID.randomUUID().toString());
            }
        });
        return result;
    }

    private String sanitizeNarrative(VisionAnalysis analysis) {
        if (analysis == null) {
            return "";
        }
        if (isNotBlank(analysis.getNarrative())) {
            return analysis.getNarrative().trim();
        }
        if (isNotBlank(analysis.getRawResponse())) {
            return analysis.getRawResponse().trim();
        }
        return "";
    }

    private List<Detection> mapToDetections(List<PredictionPayload> predictions) {
        List<Detection> detections = new ArrayList<>();
        if (predictions == null) {
            return detections;
        }
        for (PredictionPayload payload : predictions) {
            Detection detection = new Detection();
            detection.setX(payload.x != null ? payload.x : -1.0);
            detection.setY(payload.y != null ? payload.y : -1.0);
            detection.setWidth(payload.width != null ? payload.width : -1);
            detection.setHeight(payload.height != null ? payload.height : -1);
            detection.setConfidence(payload.confidence != null ? payload.confidence : 0.0);
            detection.setClassName(payload.className);
            detection.setClassId(payload.classId != null ? payload.classId : -1);
            detections.add(detection);
        }
        return detections;
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private boolean isNotBlank(String value) {
        return !isBlank(value);
    }

    private String preview(String value) {
        if (value == null) {
            return "<null>";
        }
        if (value.length() <= LOG_PREVIEW_LIMIT) {
            return value;
        }
        return value.substring(0, LOG_PREVIEW_LIMIT) + "… (truncated)";
    }

    static class StructuredPayload {
        String description;
        List<PredictionPayload> predictions;

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public List<PredictionPayload> getPredictions() {
            return predictions;
        }

        public void setPredictions(List<PredictionPayload> predictions) {
            this.predictions = predictions;
        }
    }

    static class PredictionPayload {
        Double x;
        Double y;
        Integer width;
        Integer height;
        Double confidence;
        String className;
        Integer classId;

        public Double getX() {
            return x;
        }

        public void setX(Double x) {
            this.x = x;
        }

        public Double getY() {
            return y;
        }

        public void setY(Double y) {
            this.y = y;
        }

        public Integer getWidth() {
            return width;
        }

        public void setWidth(Integer width) {
            this.width = width;
        }

        public Integer getHeight() {
            return height;
        }

        public void setHeight(Integer height) {
            this.height = height;
        }

        public Double getConfidence() {
            return confidence;
        }

        public void setConfidence(Double confidence) {
            this.confidence = confidence;
        }

        public String getClassName() {
            return className;
        }

        public void setClassName(String className) {
            this.className = className;
        }

        public Integer getClassId() {
            return classId;
        }

        public void setClassId(Integer classId) {
            this.classId = classId;
        }
    }
}
