package com.dental.service;

import com.dental.config.GeminiConfig;
import com.dental.model.Detection;
import com.dental.model.VisionAnalysis;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.genai.Client;
import com.google.genai.types.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
public class GeminiVisionService {

    private static final Logger logger = LoggerFactory.getLogger(GeminiVisionService.class);
    private static final int LOG_PREVIEW_LIMIT = 800;

    private final GeminiConfig geminiConfig;
    private final ObjectMapper objectMapper;
    private final Client client;

    public GeminiVisionService(GeminiConfig geminiConfig) {
        this.geminiConfig = geminiConfig;
        this.objectMapper = new ObjectMapper();
        this.client = Client.builder().apiKey(geminiConfig.getApiKey()).build();
    }

    public VisionAnalysis analyzeImage(File imageFile) throws Exception {
        assertApiKeyConfigured();
        logger.info("Processing image with Gemini model {}: {}", geminiConfig.getModel(), imageFile.getName());

        try {
            byte[] imageBytes = Files.readAllBytes(imageFile.toPath());
            
            String prompt = "You are a dental radiology specialist. Analyze the dental X-ray image and describe the notable findings. " +
                    "Respond in two sections: \n" +
                    "1. Summary: A concise paragraph (3-5 sentences) explaining the overall condition of the dentition and any clinically relevant concerns.\n" +
                    "2. Findings: A bullet list where each bullet follows the template '- Condition: <name>; Region: approx (<x>,<y>,<w>,<h>); Confidence: <0-1>; Notes: <short rationale>'. " +
                    "Use pixel coordinates that make sense for a 512x512 image if precise values are unavailable. Do not output JSON or code fences. Mention 'None' if no issues are detected.";

            long startTime = System.currentTimeMillis();
            
            List<Content> contents = Arrays.asList(
                Content.builder()
                    .role("user")
                    .parts(Arrays.asList(
                        Part.fromText(prompt),
                        Part.builder()
                            .inlineData(
                                Blob.builder()
                                    .mimeType(geminiConfig.getImageMimeType())
                                    .data(imageBytes)
                                    .build()
                            )
                            .build()
                    ))
                    .build()
            );
            
            GenerateContentConfig config = GenerateContentConfig.builder().build();
            GenerateContentResponse response = client.models.generateContent(geminiConfig.getModel(), contents, config);
            
            long duration = System.currentTimeMillis() - startTime;
            logger.info("Gemini response received in {} ms", duration);
            
            String responseText = response.candidates().isPresent() && !response.candidates().get().isEmpty() 
                ? response.candidates().get().get(0).content().isPresent() && !response.candidates().get().get(0).content().get().parts().isPresent() 
                    ? "No response text"
                    : response.candidates().get().get(0).content().get().parts().get().get(0).text().orElse("No text")
                : "No response";
            logger.info("Gemini raw response preview: {}", preview(responseText));
            
            return parseGeminiResponse(responseText);
        } catch (Exception e) {
            logger.error("Error processing image with Gemini: {}", e.getMessage(), e);
            throw new Exception("Failed to process image with Gemini: " + e.getMessage(), e);
        }
    }

    private void assertApiKeyConfigured() {
        if (!StringUtils.hasText(geminiConfig.getApiKey())) {
            throw new IllegalStateException("Gemini API key is not configured. Set gemini.api-key or GEMINI_API_KEY.");
        }
    }



    private VisionAnalysis parseGeminiResponse(String responseText) {
        List<Detection> detections = new ArrayList<>();
        String narrative = responseText;

        try {
            if (StringUtils.hasText(responseText)) {
                detections = extractDetectionsFromContent(responseText);
            }
        } catch (Exception e) {
            logger.error("Error parsing Gemini response: {}", e.getMessage(), e);
            detections.add(createFallbackDetection(responseText));
        }

        VisionAnalysis analysis = new VisionAnalysis();
        analysis.setNarrative(narrative);
        analysis.setRawResponse(responseText);
        analysis.setDirectDetections(detections);

        logger.info("Gemini analysis parsed: {} detections, narrative length={} chars",
                detections.size(), narrative != null ? narrative.length() : 0);

        return analysis;
    }

    private List<Detection> extractDetectionsFromContent(String content) {
        List<Detection> detections = new ArrayList<>();

        try {
            int jsonStart = content.indexOf('{');
            int jsonEnd = content.lastIndexOf('}') + 1;

            if (jsonStart >= 0 && jsonEnd > jsonStart) {
                String jsonStr = content.substring(jsonStart, jsonEnd);
                JsonNode jsonNode = objectMapper.readTree(jsonStr);

                JsonNode predictionsNode = jsonNode.get("predictions");
                if (predictionsNode != null && predictionsNode.isArray()) {
                    for (JsonNode predictionNode : predictionsNode) {
                        Detection detection = parseDetection(predictionNode);
                        if (detection != null) {
                            detections.add(detection);
                        }
                    }
                }
            }

            if (detections.isEmpty()) {
                detections.addAll(createDetectionsFromText(content));
            }

        } catch (Exception e) {
            logger.warn("Error extracting detections from content: {}", e.getMessage());
            detections.addAll(createDetectionsFromText(content));
        }

        return detections;
    }

    private Detection parseDetection(JsonNode predictionNode) {
        try {
            Detection detection = new Detection();
            detection.setX(predictionNode.get("x").asDouble());
            detection.setY(predictionNode.get("y").asDouble());
            detection.setWidth(predictionNode.get("width").asInt());
            detection.setHeight(predictionNode.get("height").asInt());
            detection.setConfidence(predictionNode.get("confidence").asDouble());
            detection.setClassName(predictionNode.get("class").asText());
            detection.setClassId(predictionNode.get("class_id").asInt());
            detection.setDetectionId(UUID.randomUUID().toString());
            return detection;
        } catch (Exception e) {
            logger.warn("Error parsing individual detection: {}", e.getMessage());
            return null;
        }
    }

    private List<Detection> createDetectionsFromText(String analysisText) {
        List<Detection> detections = new ArrayList<>();

        String lowerText = analysisText != null ? analysisText.toLowerCase() : "";

        if (lowerText.contains("cavity") || lowerText.contains("caries") || lowerText.contains("decay")) {
            Detection cavityDetection = new Detection();
            cavityDetection.setX(100.0);
            cavityDetection.setY(100.0);
            cavityDetection.setWidth(50);
            cavityDetection.setHeight(50);
            cavityDetection.setConfidence(0.85);
            cavityDetection.setClassName("cavity");
            cavityDetection.setClassId(1);
            cavityDetection.setDetectionId(UUID.randomUUID().toString());
            detections.add(cavityDetection);
        }

        if (lowerText.contains("periapical") || lowerText.contains("lesion") || lowerText.contains("infection")) {
            Detection lesionDetection = new Detection();
            lesionDetection.setX(200.0);
            lesionDetection.setY(150.0);
            lesionDetection.setWidth(40);
            lesionDetection.setHeight(40);
            lesionDetection.setConfidence(0.78);
            lesionDetection.setClassName("periapical_lesion");
            lesionDetection.setClassId(2);
            lesionDetection.setDetectionId(UUID.randomUUID().toString());
            detections.add(lesionDetection);
        }

        return detections;
    }

    private Detection createFallbackDetection(String response) {
        Detection fallback = new Detection();
        fallback.setX(0.0);
        fallback.setY(0.0);
        fallback.setWidth(0);
        fallback.setHeight(0);
        fallback.setConfidence(0.5);
        fallback.setClassName("analysis_complete");
        fallback.setClassId(0);
        fallback.setDetectionId(UUID.randomUUID().toString());
        return fallback;
    }

    private String preview(String value) {
        if (value == null) {
            return "<null>";
        }
        if (value.length() <= LOG_PREVIEW_LIMIT) {
            return value;
        }
        return value.substring(0, LOG_PREVIEW_LIMIT) + "… (truncated)";
    }
}
