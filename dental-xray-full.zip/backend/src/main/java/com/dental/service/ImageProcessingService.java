package com.dental.service;

import com.dental.model.ImageInfo;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.BulkData;
import org.dcm4che3.data.Fragments;
import org.dcm4che3.data.Tag;
import org.dcm4che3.imageio.plugins.dcm.DicomImageReadParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;

@Service
public class ImageProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(ImageProcessingService.class);
    
    @Autowired
    private DicomProcessingService dicomProcessingService;

    public File convertDicomToJpeg(File dicomFile) throws IOException {
        logger.info("Converting DICOM file to JPEG: {}", dicomFile.getName());
        File jpegFile = File.createTempFile("dicom_converted_", ".jpg");
        
        try {
            BufferedImage image = readDicomImageWithDcm4che(dicomFile);
            if (image == null) {
                throw new IOException("Failed to read DICOM image data");
            }
            logger.info("Successfully read DICOM image: {}x{} pixels, type: {}", 
                image.getWidth(), image.getHeight(), image.getType());
            
            if (image.getType() == 0 || image.getType() == BufferedImage.TYPE_USHORT_GRAY || 
                image.getType() == BufferedImage.TYPE_CUSTOM) {
                logger.info("Converting image type {} to standard format for JPEG compatibility", image.getType());
                image = convertToStandardFormat(image);
            }
            
            if (!ImageIO.write(image, "jpg", jpegFile)) {
                throw new IOException("Failed to write JPEG file");
            }
            logger.info("Successfully converted DICOM to JPEG: {}", jpegFile.getName());
            
        } catch (Exception e) {
            logger.error("Error converting DICOM to JPEG: {}", e.getMessage(), e);
            if (jpegFile.exists()) {
                jpegFile.delete();
            }
            throw new IOException("Failed to convert DICOM to JPEG: " + e.getMessage(), e);
        }
        return jpegFile;
    }
    
    private BufferedImage convertToStandardFormat(BufferedImage source) {
        int width = source.getWidth();
        int height = source.getHeight();
        
        boolean isGrayscale = source.getColorModel().getNumComponents() == 1;
        
        BufferedImage result;
        if (isGrayscale) {
            result = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        } else {
            result = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        }
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = source.getRGB(x, y);
                result.setRGB(x, y, rgb);
            }
        }
        
        logger.info("Converted {}x{} image from type {} to type {} (pixel-perfect copy)", 
            width, height, source.getType(), result.getType());
        return result;
    }
    
    private BufferedImage readDicomImageWithDcm4che(File dicomFile) throws IOException {
        try (ImageInputStream iis = ImageIO.createImageInputStream(dicomFile)) {
            Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("DICOM");
            if (!readers.hasNext()) {
                throw new IOException("No DICOM ImageReader available");
            }
            ImageReader reader = readers.next();
            try {
                reader.setInput(iis, false);
                ImageReadParam param = reader.getDefaultReadParam();
                if (param instanceof DicomImageReadParam) {
                    ((DicomImageReadParam) param).setAutoWindowing(true);
                }
                return reader.read(0, param);
            } catch (RuntimeException e) {
                if (e.getMessage() != null && e.getMessage().contains("No Reader for format")) {
                    logger.warn("dcm4che ImageReader failed ({}), attempting fallback extraction", e.getMessage());
                    return readEncapsulatedJpegFallback(dicomFile);
                }
                throw e;
            } finally {
                reader.dispose();
            }
        }
    }
    
    private BufferedImage readEncapsulatedJpegFallback(File dicomFile) throws IOException {
        logger.info("Attempting to extract encapsulated JPEG data from DICOM");
        
        Attributes attrs = dicomProcessingService.readDicomAttributes(dicomFile);
        
        Object pixelData = attrs.getValue(Tag.PixelData);
        
        if (pixelData == null) {
            throw new IOException("No pixel data found in DICOM file");
        }
        
        if (pixelData instanceof Fragments) {
            Fragments fragments = (Fragments) pixelData;
            logger.info("Found {} fragments of encapsulated pixel data", fragments.size());

            for (int i = 1; i < fragments.size(); i++) {
                Object fragment = fragments.get(i);
                byte[] jpegData = null;
                
                if (fragment instanceof byte[]) {
                    jpegData = (byte[]) fragment;
                } else if (fragment instanceof BulkData) {
                    logger.info("Fragment {} is BulkData, skipping for now", i);
                    continue;
                }
                
                if (jpegData != null && jpegData.length > 0) {
                    logger.info("Trying to decode fragment {} ({} bytes) as JPEG", i, jpegData.length);
                    try {
                        // Try to decode as standard JPEG using Java's ImageIO
                        BufferedImage image = ImageIO.read(new ByteArrayInputStream(jpegData));
                        if (image != null) {
                            logger.info("Successfully decoded JPEG data: {}x{}", image.getWidth(), image.getHeight());
                            return image;
                        }
                    } catch (Exception e) {
                        logger.warn("Failed to decode fragment {} as JPEG: {}", i, e.getMessage());
                    }
                }
            }
            throw new IOException("Could not decode any JPEG fragments from encapsulated pixel data");
        }
        
        throw new IOException("Pixel data is not in encapsulated format (not Fragments)");
    }

    public ImageInfo createImageInfo(File originalDicomFile, File convertedFile) {
        ImageInfo imageInfo = new ImageInfo();
        try {
            Attributes attrs = dicomProcessingService.readDicomAttributes(originalDicomFile);
            int rows = attrs.getInt(Tag.Rows, 0);
            int columns = attrs.getInt(Tag.Columns, 0);
            imageInfo.setOriginalShape(Arrays.asList(rows, columns));
            imageInfo.setConvertedSize(Arrays.asList(rows, columns));
            int bitsAllocated = attrs.getInt(Tag.BitsAllocated, 16);
            imageInfo.setOriginalDtype(bitsAllocated == 8 ? "uint8" : "uint16");
            imageInfo.setPixelArrayMin(0.0);
            imageInfo.setPixelArrayMax((double) ((1 << attrs.getInt(Tag.BitsStored, bitsAllocated)) - 1));
            imageInfo.setConvertedFormat("JPEG");
            imageInfo.setPhotometricInterpretation(attrs.getString(Tag.PhotometricInterpretation));
            imageInfo.setTransferSyntax(attrs.getString(Tag.TransferSyntaxUID, "Unknown"));
        } catch (Exception e) {
            logger.error("Error creating image info: {}", e.getMessage());
            imageInfo.setOriginalShape(Arrays.asList(512, 512));
            imageInfo.setConvertedSize(Arrays.asList(512, 512));
            imageInfo.setConvertedFormat("JPEG");
            imageInfo.setOriginalDtype("uint16");
            imageInfo.setPixelArrayMin(0.0);
            imageInfo.setPixelArrayMax(4095.0);
        }
        return imageInfo;
    }

    public boolean isValidImageFormat(File file) {
        String name = file.getName().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".jpeg") || 
               name.endsWith(".png") || name.endsWith(".bmp");
    }

    public ImageInfo createImageInfoForRegularImage(File imageFile) throws IOException {
        logger.info("Creating image info for regular image file: {}", imageFile.getName());
        
        BufferedImage image = ImageIO.read(imageFile);
        if (image == null) {
            throw new IOException("Unable to read image file: " + imageFile.getName());
        }
        
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.setConvertedSize(Arrays.asList(image.getWidth(), image.getHeight()));
        
        String format = getImageFormat(imageFile.getName());
        imageInfo.setConvertedFormat(format.toUpperCase());
        imageInfo.setOriginalShape(Arrays.asList(image.getWidth(), image.getHeight()));
        
        // For regular images, we'll set basic metadata
        imageInfo.setOriginalDtype(getImageDataType(image));
        imageInfo.setPixelArrayMin(0.0);
        imageInfo.setPixelArrayMax(getMaxPixelValue(image));
        
        // Set photometric interpretation for regular images
        imageInfo.setPhotometricInterpretation(image.getColorModel().getNumComponents() > 1 ? "RGB" : "MONOCHROME2");
        imageInfo.setTransferSyntax("1.2.840.10008.1.2.1"); // Explicit VR Little Endian
        
        return imageInfo;
    }
    
    private String getImageFormat(String filename) {
        String lowerCase = filename.toLowerCase();
        if (lowerCase.endsWith(".png")) return "PNG";
        if (lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg")) return "JPEG";
        if (lowerCase.endsWith(".webp")) return "WEBP";
        return "UNKNOWN";
    }
    
    private String getImageDataType(BufferedImage image) {
        switch (image.getType()) {
            case BufferedImage.TYPE_BYTE_GRAY:
            case BufferedImage.TYPE_3BYTE_BGR:
            case BufferedImage.TYPE_4BYTE_ABGR:
                return "uint8";
            case BufferedImage.TYPE_USHORT_GRAY:
                return "uint16";
            default:
                return "uint8";
        }
    }
    
    private double getMaxPixelValue(BufferedImage image) {
        switch (image.getType()) {
            case BufferedImage.TYPE_BYTE_GRAY:
            case BufferedImage.TYPE_3BYTE_BGR:
            case BufferedImage.TYPE_4BYTE_ABGR:
                return 255.0;
            case BufferedImage.TYPE_USHORT_GRAY:
                return 65535.0;
            default:
                return 255.0;
        }
    }
}
