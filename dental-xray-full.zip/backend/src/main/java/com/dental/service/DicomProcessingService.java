package com.dental.service;

import com.dental.model.DicomMetadata;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.io.DicomInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

@Service
public class DicomProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(DicomProcessingService.class);

    public DicomMetadata extractDicomMetadata(File dicomFile) throws IOException {
        logger.info("Extracting metadata from DICOM file: {}", dicomFile.getName());
        
        DicomMetadata metadata = new DicomMetadata();
        
        try (DicomInputStream dis = new DicomInputStream(dicomFile)) {
            Attributes attrs = dis.readDataset();
            
            // Patient Information
            metadata.setPatientId(attrs.getString(Tag.PatientID));
            metadata.setPatientName(attrs.getString(Tag.PatientName));
            metadata.setPatientBirthDate(attrs.getString(Tag.PatientBirthDate));
            metadata.setPatientSex(attrs.getString(Tag.PatientSex));
            
            // Study Information
            metadata.setStudyDate(attrs.getString(Tag.StudyDate));
            metadata.setStudyTime(attrs.getString(Tag.StudyTime));
            metadata.setStudyDescription(attrs.getString(Tag.StudyDescription));
            metadata.setSeriesDescription(attrs.getString(Tag.SeriesDescription));
            metadata.setStudyInstanceUID(attrs.getString(Tag.StudyInstanceUID));
            metadata.setSeriesInstanceUID(attrs.getString(Tag.SeriesInstanceUID));
            metadata.setSOPInstanceUID(attrs.getString(Tag.SOPInstanceUID));
            
            // Equipment Information
            metadata.setModality(attrs.getString(Tag.Modality, "CR"));
            metadata.setManufacturer(attrs.getString(Tag.Manufacturer));
            metadata.setManufacturerModelName(attrs.getString(Tag.ManufacturerModelName));
            metadata.setInstitutionName(attrs.getString(Tag.InstitutionName));
            
            // Image Information
            metadata.setRows(attrs.getInt(Tag.Rows, 0));
            metadata.setColumns(attrs.getInt(Tag.Columns, 0));
            
            // Pixel Spacing
            double[] pixelSpacing = attrs.getDoubles(Tag.PixelSpacing);
            if (pixelSpacing != null && pixelSpacing.length >= 2) {
                metadata.setPixelSpacing(Arrays.asList(pixelSpacing[0], pixelSpacing[1]));
            }
            
            // Pixel Data Information
            metadata.setBitsAllocated(attrs.getInt(Tag.BitsAllocated, 0));
            metadata.setBitsStored(attrs.getInt(Tag.BitsStored, 0));
            metadata.setHighBit(attrs.getInt(Tag.HighBit, 0));
            metadata.setPhotometricInterpretation(attrs.getString(Tag.PhotometricInterpretation));
            metadata.setSamplesPerPixel(attrs.getInt(Tag.SamplesPerPixel, 1));
            
            // Window Center/Width for display
            double[] windowCenter = attrs.getDoubles(Tag.WindowCenter);
            double[] windowWidth = attrs.getDoubles(Tag.WindowWidth);
            if (windowCenter != null && windowCenter.length > 0) {
                metadata.setWindowCenter(windowCenter[0]);
            }
            if (windowWidth != null && windowWidth.length > 0) {
                metadata.setWindowWidth(windowWidth[0]);
            }
            
            String transferSyntax = dis.getTransferSyntax();
            metadata.setTransferSyntax(transferSyntax);
            
            logger.info("Successfully extracted metadata: Patient={}, Modality={}, Dimensions={}x{}", 
                metadata.getPatientId(), metadata.getModality(), metadata.getRows(), metadata.getColumns());
            
        } catch (Exception e) {
            logger.error("Error extracting DICOM metadata: {}", e.getMessage(), e);
            throw new IOException("Failed to extract DICOM metadata: " + e.getMessage(), e);
        }
        
        return metadata;
    }

    public boolean isDicomFile(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            return false;
        }
        
        String name = file.getName().toLowerCase();
        if (name.endsWith(".dcm") || name.endsWith(".dicom")) {
            return verifyDicomStructure(file);
        }
        
        return verifyDicomStructure(file);
    }
    
    private boolean verifyDicomStructure(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            long skipped = fis.skip(128);
            if (skipped != 128) {
                return false;
            }
            
            byte[] signature = new byte[4];
            int bytesRead = fis.read(signature);
            
            if (bytesRead == 4) {
                String dicmSignature = new String(signature);
                return "DICM".equals(dicmSignature);
            }
        } catch (Exception e) {
            logger.debug("Error verifying DICOM structure for file: {}", file.getName(), e);
        }
        
        return false;
    }
    
    public Attributes readDicomAttributes(File dicomFile) throws IOException {
        try (DicomInputStream dis = new DicomInputStream(dicomFile)) {
            return dis.readDataset();
        }
    }
}