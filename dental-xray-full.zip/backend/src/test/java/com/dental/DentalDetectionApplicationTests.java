package com.dental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@TestPropertySource(properties = {
    "gemini.base-url=https://generativelanguage.googleapis.com",
    "gemini.api-key=test-key",
    "upload.max-file-size=10MB"
})
class DentalDetectionApplicationTests {

    @Test
    void contextLoads() {
        // This test ensures that the Spring context loads properly
    }

    @Test  
    void applicationStarts() {
        // Test that the main application class exists and can be instantiated
        DentalDetectionApplication app = new DentalDetectionApplication();
        assertNotNull(app);
    }
}